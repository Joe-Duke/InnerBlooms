# InnerBloom

A relaxing, customizable affirmation app with AI generation, voice input, and daily lock screen notifications.